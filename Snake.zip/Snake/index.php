<?php
  require 'head.php';
  require 'game.php';
  require 'footer.php';
?>
